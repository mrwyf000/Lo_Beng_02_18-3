package com.example.carparkmainmenu;

import androidx.lifecycle.ViewModel;

public class MapViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
