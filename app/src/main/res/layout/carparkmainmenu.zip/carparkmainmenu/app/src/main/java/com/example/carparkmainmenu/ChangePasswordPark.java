package com.example.carparkmainmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ChangePasswordPark extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password_park);
    }
}
