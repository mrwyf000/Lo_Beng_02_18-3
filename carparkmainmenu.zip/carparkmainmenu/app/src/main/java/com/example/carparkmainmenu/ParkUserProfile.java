package com.example.carparkmainmenu;

public class ParkUserProfile {
    public String userName;
    public String userEmail;

    public ParkUserProfile(String userName, String userEmail) {
        this.userName = userName;
        this.userEmail = userEmail;
    }
}
