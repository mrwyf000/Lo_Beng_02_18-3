package com.example.carparkmainmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EasyPark extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy_park);
    }
}
